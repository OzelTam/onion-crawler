# Onion-Crawler
### Description
C# based Tor/Onion Web crawler.
There might be some errors/bugs so,
feel free to contribute and mess with my code.

Old version was a mess this one is a bit more tolerable :grin:.


## Requirement
Download and run Tor Expert Bundle form https://www.torproject.org/download/tor/ (Windows)


## API's Used
- https://epplussoftware.com/
- https://github.com/MihaZupan/HttpToSocks5Proxy
- https://html-agility-pack.net/


## Work Stages
- [x] Object classes.
- [x] Main methods and functions.
- [x] GUI.
- [x] Multithreading/ Async functions.
- [ ] Pretty code.
- [ ] Pretty GUI and UX.
- [x] Full of Bodge Code	:neutral_face:
